# pistol image > 2023-03-09 1:33pm
https://universe.roboflow.com/julian-felipe/pistol-image

Provided by a Roboflow user
License: CC BY 4.0

